## CHANGELOG

### Version 0.1.1 (2023-11-01)

-   Feat: Add fly.toml for fly.io deployment
-   Feat: Change port to 8080 in Dockerfile

### Version 0.1.0 (2023-11-01)

-   Initial release
